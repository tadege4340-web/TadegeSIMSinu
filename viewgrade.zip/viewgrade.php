<?php
// ======================
// BACKEND (VIEW ONLY)
// ======================

// database connection
$conn = new mysqli("localhost", "root", "", "lab");

// check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} // include your database connection
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Student Grades</title>
    <link rel="stylesheet" href="login.css">

  <style>
    table {
        border-collapse: collapse;
        width: 100%;
        margin-top: 20px;
        background: #fff;
    }
    th, td {
        border: 1px solid #333;
        padding: 8px;
        text-align: center;
    }
    th {
        background: #2c3e50;
        color: white;
    }
    tr:nth-child(even) {
        background: #f2f2f2;
    }
    h2 {
        text-align: center;
        margin-top: 20px;
    }
  </style>
</head>
<body>
    
<div class="header">
  <div class="logo">
    <img src="logoinu.jpg">
  </div>

  <div class="title">
    <h1>INJIBARA UNIVERSITY <br> STUDENT INFORMATION MANAGEMENT SYSTEM</h1>
  </div>
</div>

<div class="menu">
  <a href="a.html">HOME</a>
  <a href="B.html">CONTACT US</a>
  <a href="C.html">NEWS</a>
</div>


<h1>All Student Grades and Information</h1>

<table>
    <thead>
        <tr>
            <th>Student ID</th>
            <th>College</th>
            <th>Department</th>
            <th>Course ID</th>
            <th>Grade</th>
            <th>Semester</th>
            <th>Academic Year</th>
            <th>Cumulative GPA</th>
        </tr>
    </thead>
    <tbody>
        <?php
        $sql = "SELECT * FROM users4 ORDER BY academic_year DESC, semester ASC";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                echo "<tr>
                        <td>{$row['student_id']}</td>
                        <td>{$row['college']}</td>
                        <td>{$row['department']}</td>
                        <td>{$row['course_id']}</td>
                        <td>{$row['grade']}</td>
                        <td>{$row['semester']}</td>
                        <td>{$row['academic_year']}</td>
                        <td>{$row['gpa']}</td>
                      </tr>";
            }
        } else {
            echo "<tr><td colspan='8' style='color:red;'>No grades added yet.</td></tr>";
        }

        $conn->close();
        ?>
    </tbody>
</table>

</body>
</html>